Hello. Welcome to the groupcool website for used electronics

Here is the Mongolabs URI and shell along with the login credentials.
Below is alsow the Azure URL with credentials to login.

MongoLabs

To connect using the shell:
mongo ds034878.mongolab.com:34878/dbgroupc -u dbadmin -p dbpass1

To connect using a driver via the standard URI:
  mongodb://dbadmin:dbpass1@ds034878.mongolab.com:34878/dbgroupc

To login to the mongolabs account:
u: dbgroupc
p: dbgroupcpass1

Azure

URL: groupcool.azurewebsites.net
u:mysite
p:123
