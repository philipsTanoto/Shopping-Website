'use strict';

/**
 * @ngdoc overview
 * @name To Do App
 * @description
 * # To do Application
 *
 * Main module of the application.
 */
angular
.module('shoppingApp')

.controller('ItemsCtrl', ['$scope',  '$http', '$route', '$rootScope',
	function($scope, $http, $route) {
		
          $scope.getItems = function () {
               
				
			//$scope.listId = $route.current.params.listId;
			var url = '/app/items';
			//$scope.listName = myItem();
			$http.get(url).success(function(data, status, headers, config) {
			   $scope.results = data;
			   var items = [];
			   
			   for (var i = 0; i < data.length; i++) {
				   
				   items[i] = { 
								"category": data.category,
								"type": data[i].type,
								"brand": data[i].brand,
								"model":  data[i].model,
								"os":  data[i].os,
								"price":  data[i].price,
								"condition":  data[i].condition,
								"owner":  data[i].owner,
								"description":  data[i].description,
								"photo":  data[i].photo
							};
							
			   }
			   $rootScope.items = items;
			});
			//$scope.listName = myItem.getName($rootScope.listNames, $scope.listId);
 
              
            }
        }
]);