'use strict';

/**
 * @ngdoc overview
 * @name To Do App
 * @description
 * # To do Application
 *
 * Main module of the application.
 */
angular
.module('shoppingApp')

.controller('ItemCtrl', ['$scope',  '$http', '$route', '$rootScope',
	function($scope, $http, $route) {

			$scope.getItemByID = function (){
				$scope.itemID = $route.current.params.itemID;
				var url = '/item/' + $scope.itemID;
				$http.get(url).success(function(data, status, headers, config){
					$scope.results = data;
					var temp = {
						"category": data.category,
						"type": data.type,
						"brand": data.brand,
						"model":  data.model,
						"os":  data.os,
						"price":  data.price,
						"condition":  data.condition,
						"owner":  data.owner,
						"description":  data.description,
						"photo":  data.photo
					};
					$rootScope.temp = temp;
					
			});
		};
		$scope.addToCart = function (){
			var putUrl = '/cart/' + $scope.results._id;
				alert(putUrl);
                var posting = $http({
                    method: 'PUT',
                    /*posting to /PUT */
                    url: putUrl,
                    data: $scope.item,
                    processData: false
                });
                posting.success(function (response) {
                    /*executed when server responds back*/
                    $http.get('/#/user/inventory');
                });
			var message = "Item added to cart";
			alert(message);
		};
     }
	 
	 
]);

