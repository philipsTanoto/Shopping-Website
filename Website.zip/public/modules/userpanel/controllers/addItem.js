'use strict';

/**
 * @ngdoc overview
 * @name To Do App
 * @description
 * # To do Application
 *
 * Main module of the application.
 */
angular
.module('shoppingApp')

.controller('AddCtrl', ['$scope',  '$http', '$route',
	
	
	function($scope, $http, $route) {
		$scope.item = {}
		$scope.data = {}
		$scope.response = {}
          $scope.send = function () {
                var posting = $http({
                    method: 'POST',
                    /*posting to /post */
                    url: '/item',
                    data: $scope.item,
                    processData: false
                });
				
                posting.success(function (response) {
                    /*executed when server responds back*/
                    $route.reload();
                });
            }
        }
]);