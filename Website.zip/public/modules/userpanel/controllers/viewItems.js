'use strict';

/**
 * @ngdoc overview
 * @name To Do App
 * @description
 * # To do Application
 *
 * Main module of the application.
 */
angular
.module('shoppingApp')

.controller('InventoryCtrl', ['$scope',  '$http', '$route', '$rootScope',
	function($scope, $http, $route) {
		
          $scope.getItems = function () {
			//$scope.listId = $route.current.params.listId;
			var url = '/item';
			//$scope.listName = myItem();
			$http.get(url).success(function(data, status, headers, config) {
			   $scope.results = data;
			  /*var items = [];
			   
				for (var i = 0; i < data.length; i++) {
				   
				   items[i] = { 
								"category": data[i].category,
								"type": data[i].type,
								"brand": data[i].brand,
								"model":  data[i].model,
								"os":  data[i].os,
								"price":  data[i].price,
								"condition":  data[i].condition,
								"owner":  data[i].owner,
								"description":  data[i].description,
								"photo":  data[i].photo
							};			
			   }
			   $rootScope.items = items;*/
			});
			
          };
		  
		   $scope.getAllItems = function () {
			//$scope.listId = $route.current.params.listId;
			var url = '/items';
			//$scope.listName = myItem();
			$http.get(url).success(function(data, status, headers, config) {
			   $scope.results = data;
			 
			});
			
          };
			
			$scope.getItemsInCart= function(){
				var url = '/cart';
			//$scope.listName = myItem();
				$http.get(url).success(function(data, status, headers, config) {
				   $scope.results = data;
					
				});
			};
			
		$scope.removeById = function(itemID){
			var url = '/item/' + itemID;
			var message = "Item removed";
			
			$http.delete(url);
				alert(message);
			$route.reload();
		};
		
		$scope.removeFromCart = function(itemID){
			var putUrl = '/cart/remove/' + itemID;
				alert(putUrl);
                var posting = $http({
                    method: 'PUT',
                    /*posting to /PUT */
                    url: putUrl,
                    data: $scope.item,
                    processData: false
                });
                posting.success(function (response) {
                    /*executed when server responds back*/
                    $http.get('/#/user/inventory');
                });
			var message = "Item removed from cart";
			alert(message);
			$route.reload();
		};
		
     }
]);

