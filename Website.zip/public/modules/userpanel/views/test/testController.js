 
 
function AddCtrl($scope, $http) {
            /*$http directive is used to communicate ot the server */
            $scope.data = {}
            $scope.response = {}
 
            $scope.send = function () {
                /*executed when submit is clicked*/
                console.log("inside click");
                console.log($scope.data.textdata);
 
                var posting = $http({
                    method: 'POST',
                    /*posting to /post */
                    url: '/post',
                    data: $scope.data,
 
                    processData: false
                })
                posting.success(function (response) {
                    /*executed when server responds back*/
                    console.log(response);
                    $scope.response.data = response;
                });
            }
        };