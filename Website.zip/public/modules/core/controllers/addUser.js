'use strict';

/**
 * @ngdoc overview
 * @name To Do App
 * @description
 * # To do Application
 *
 * Main module of the application.
 */
angular
.module('shoppingApp')

.controller('CreateUserCtrl', ['$scope',  '$http', '$route',
	
	
	function($scope, $http, $route) {
		$scope.user = {}
		$scope.data = {}
		$scope.response = {}
          $scope.register = function () {
                var posting = $http({
                    method: 'POST',
                    /*posting to /post */
                    url: '/user/',
                    data: $scope.user,
                    processData: false
					
                });
				
                posting.success(function (response) {
                    /*executed when server responds back*/
                    $http.get(res);
                });
            }
        }
]);