'use strict';

/**
 * @ngdoc overview
 * @name To Do App
 * @description
 * # To do Application
 *
 * Main module of the application.
 */
angular
  .module('shoppingApp', [
    'ngAnimate',
    'ngAria',
    'ngCookies',
    'ngMessages',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'modules/core/views/welcome.html'
	  })
	  .when('/login', {
		controller: 'loginCtrl',
        templateUrl: 'modules/core/views/login.html'
	  })  
	  .when('/cart', {
        templateUrl: 'modules/cart/cart.html'
	  }) 
	  .when('/createuser', {
        templateUrl: 'modules/core/views/newuser.html'
	  })  
	  .when('/about', {
        templateUrl: 'modules/others/about.html'
	  })
	  .when('/user/contact', {
        templateUrl: 'modules/others/contactUs.html'
	  })  
	  .when('/user/accounthelp', {
        templateUrl: 'modules/others/accountHelp.html'
	  }) 
	  .when('/user/summary', {
        templateUrl: 'modules/userpanel/views/summary.html'
	  })  
	  .when('/user/inventory',{
		  controller: 'InventoryCtrl',
		  templateUrl: 'modules/userpanel/views/inventory.html'
	  })
	  .when('/items/:itemID',{
		  controller: 'ItemCtrl',
		  templateUrl: 'modules/userpanel/views/item.html'
	  })
	 .when('/user/add', {
		controller: 'AddCtrl',
        templateUrl: 'modules/userpanel/views/addItem.html'
	  })  
	  .when('/items/:editID/edit', {
		controller: 'EditCtrl',
        templateUrl: 'modules/userpanel/views/editItem.html'
	  })  
	  
	  //  .when('/items/:listId', {
    //    templateUrl: 'modules/items/views/itemsView.html',
    //    controller: 'ItemsCtrl'
    //  })
      .otherwise({
        redirectTo: '/'
      });
  });
