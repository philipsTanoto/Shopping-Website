'use strict';

/**
 * @ngdoc overview
 * @name To Do App
 * @description
 * # To do Application
 *
 * Main module of the application.
 */
angular
.module('shoppingApp')

.controller('loginCtrl', ['$scope',  '$http', '$route',
	
	
	function($scope, $http, $route) {
		$scope.login = {}
		$scope.data = {}
		$scope.response = {}
        $scope.signin = function () {
                var posting = $http({
                    method: 'POST',
                    /*posting to /post */
                    url: '/login/',
                    data: $scope.login,
                    processData: false
					
                });
				
                posting.success(function (response) {
                    /*executed when server responds back*/
				
                });
            }
        }
]);