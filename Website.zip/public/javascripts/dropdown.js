var category =  '<option selected="selected" value=""> Choose Category </option><option value="Computer">Computer</option><option value="Phone">Phone</option>';
var phoneType = '<option selected="selected" value=""> Choose Type </option><option value="16GB">16GB</option><option value="32GB">32GB</option><option value="64GB">64GB</option><option value="1ZB">1ZB</option>';
var computerType = '<option selected="selected" value=""> Choose Type </option><option value="256GB-SSD">256GB-SSD</option><option value="512GB-SSD">512GB-SSD</option><option value="1TB-SSD">1TB-SSD</option><option value="1MB-FLOPPY">1MB-FLOPPY</option>';
var phoneBrand = '<option selected="selected" value=""> Choose Brand </option><option value="NOKIE">NOKIE</option><option value="KIA">KIA</option><option value="SAMSONG">SAMSONG</option><option value="APPEL">APPEL</option>';
var computerBrand = '<option selected="selected" value=""> Choose Brand </option><option value="LENOFO">LENOFO</option><option value="DALE">DALE</option><option value="ALIONWARE">ALIONWARE</option><option value="RAZOR">RAZOR</option>'; 
var phoneModel = '<option selected="selected" value=""> Choose Model </option><option value="S1">S1</option><option value="S5">S5</option><option value="S99">S99</option><option value="ALPHAOMEGAEPSILON">ALPHAOMEGAEPSILON</option>';
var computerModel = '<option selected="selected" value=""> Choose Model </option><option value="G1">G1</option><option value="B1">B1</option><option value="E1">E1</option><option value="GOLD-EDITION">GOLD-EDITION</option>'; 
var phoneOS = '<option selected="selected" value=""> Choose OS </option><option value="Android">Android</option><option value="APPLE">APPLE</option><option value="WINDOWS">WINDOWS</option><option value="LINUX">LINUX</option>';
var computerOS = '<option selected="selected" value=""> Choose OS </option><option value="MacOSXL">MacOSXL</option><option value="WindowsX">WindowsX</option><option value="ROOFS">ROOFS</option><option value="DOORS">DOORS</option>'; 
var Condition = '<option selected="selected" value=""> Choose Condition </option><option value="New">New</option><option value="Like_New">Used-Like New</option><option value="Good">Used-Good</option><option value="Acceptable">Used-Acceptable</option>'; 
$(document).ready(function(){
			$("select#categoryChoice").html(category).change(function(){
        if($(this).val() =="Computer"){
            $("select#type1").html(computerType);
			$("select#brand1").html(computerBrand);
			$("select#model1").html(computerModel);
			$("select#OS1").html(computerOS);
			$("select#Con").html(Condition);
        }else if($(this).val() == "Phone"){
            $("select#type1").html(phoneType);
			$("select#brand1").html(phoneBrand);
			$("select#model1").html(phoneModel);
			$("select#OS1").html(phoneOS);
			$("select#Con").html(Condition);
		}
		});
});

