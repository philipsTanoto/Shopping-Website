 function retrieveItemsFromServer(url,id, mode){
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			
			var items = JSON.parse(xmlhttp.responseText);
			if (mode ==1)
			populateItemsView(id, items);
			else if (mode ==2)
			showAllItems(id,items);
		}
	}
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

//inject code
function showAllItems(elementId, items){
	//var lists = retrieveItemsJSON('mysite');
	element = document.getElementById(elementId);
	var pagetitle = document.getElementById(elementId).getAttribute("name");
	var newElement = "<h3>" + pagetitle + "</h3>";
	if (items.length <1 )
		newElement += "You have not list any item";
	for (var i = 0; i < items.length; i++) {
		newElement += "<div class=\"  panel panel-default post  \">";
		newElement += "<div class=\"panel-heading\"><a href=\"item\\" +(i+1)+"\">" + (i+1) + ". " + items[i].model + "</a></div>";
		newElement += "<div class=\"panel-body\">";
		newElement += "<div class=\"col-sm-8 col-md-5\">";
		newElement += "<div  class=\"\"><img src=\" " + items[i].thumb + "\" alt=\"Generic placeholder thumbnail\"></div>";
		newElement += "</div>";
		newElement += "</div>";
		newElement += "<table class=\"table\" style=\"font-size:10pt;\">";
		newElement += "<tbody>";
		newElement += "<tr>";
		newElement += "<td>Price: $<span>" + items[i].price + "</span></td>";
		newElement += "<td align=\"right\">Category: <span class=\"badge\">" + items[i].category + "</span></td>";
		newElement += "</tr>";
		newElement += "</tbody>";
		newElement += "</table>";
		newElement += "</div>";
		newElement += "</div>";
	}

	element.innerHTML = newElement;
}

//href =\"javascript:editItem("+ items[i]+ ","+ "'item-edit'"+")\"
function populateEdit(elementId, items, id){
	var item  = items[id];
	
	 element = document.getElementById(elementId);
	 var pagetitle = document.getElementById(elementId).getAttribute("name");
	 var newElement = "<h3>" + item.model + "</h3>";
	document.getElementById("item-edit").style.display = "block";
	document.getElementById("inventory-view").style.display = "none";

	
	newElement += "<div class=\"panel panel-default\">";	
	newElement += "<div class=\"panel-heading\">Category</div>";
	newElement += "<div class=\"panel-body\" style=\"display:block;\">";
	newElement+= "<select class=\"form-control\" id=\"categoryChoice\">";
	newElement += "<Option selected=\"selected\">" + item.category +"</Option>";
	newElement +="</select>";
	newElement += "</div>";
	newElement += "</div>";
	
	newElement += "<div class=\"panel panel-default\">";
	newElement += "<div class=\"panel-heading\">Model</div>";
	newElement += "<div class=\"panel-body\" style=\"display:block;\">";
	newElement+= "<select class=\"form-control\" id=\"categoryChoice\">";
	newElement += "<Option selected=\"selected\">" + item.model +"</Option>";
	newElement +="</select>";
	newElement += "</div>";
	newElement += "</div>";
	
	newElement += "<div class=\"panel panel-default\">";
	newElement += "<div class=\"panel-heading\">Type</div>";
	newElement += "<div class=\"panel-body\" style=\"display:block;\">";
	newElement+= "<select class=\"form-control\" id=\"categoryChoice\">";
	newElement += "<Option selected=\"selected\">" + item.type +"</Option>";
	newElement +="</select>";
	newElement += "</div>";
	newElement += "</div>";
	
	newElement += "<div class=\"panel panel-default\">";
	newElement += "<div class=\"panel-heading\">Brand</div>";
	newElement += "<div class=\"panel-body\" style=\"display:block;\">";
	newElement+= "<select class=\"form-control\" id=\"categoryChoice\">";
	newElement += "<Option selected=\"selected\">" + item.brand +"</Option>";
	newElement +="</select>";
	newElement += "</div>";
	newElement += "</div>";
	
	newElement += "<div class=\"panel panel-default\">";
	newElement += "<div class=\"panel-heading\">Price</div>";
	newElement += "<div class=\"panel-body\" style=\"display:block;\">";
	newElement += "<input value =\""+ item.price+"\" ></input>"
	newElement += "</div>";
	newElement += "</div>";
	
	newElement += "<div class=\"panel panel-default\">";
	newElement += "<div class=\"panel-heading\">Photos</div>";
	newElement += "<div class=\"panel-body\" style=\"display:block;\">";
	newElement += "<div class=\"col-sm-6 col-md-3\">";
	newElement += "<div  class=\"thumbnail\"><img src=\" " + item.thumb + "\" alt=\"Generic placeholder thumbnail\"></div>";
	newElement += "</div>";
	newElement += "</div>";
	newElement += "</div>";
	
	newElement += "<button class = \"btn btn-sm\" onclick=\"javascript:commitUpdateItem()\">Update!</btn>";
	
	
	element.innerHTML = newElement;
}

function populateItemsView(elementId, items) {
	//var items = retrieveItemsJSON('mysite');
	element = document.getElementById(elementId);
	var pagetitle = document.getElementById(elementId).getAttribute("name");
	var newElement = "<h3>" + pagetitle + "</h3>";
	if (items.length <1 )
		newElement += "You have not list any item";
	for (var i = 0; i < items.length; i++) {
		var item = items[i];
		newElement += "<div class=\"panel panel-default\">";
		
		newElement += "<div class=\"panel-heading\"><a href=\"item\\" +(i+1)+"\">" + (i+1) + ". " + item.model + " </a>";
		newElement += "<a href =\"javascript:editItem('javascripts/items.json', 'item-edit',"+i+")\"><span class=\"glyphicon glyphicon-pencil button\"></span></a>";
		newElement += "<a href=\"remove\\" +(i+1)+ "\">" +"<span class=\"glyphicon glyphicon-remove button button-right\"></span></a>";
		
		newElement += "</div>";
		
		newElement += "<div class=\"panel-body\" style=\"display:block;\">";
		newElement += "<div class=\"col-sm-6 col-md-3\">";
		newElement += "<div  class=\"thumbnail\"><img src=\" " + item.thumb + "\" alt=\"Generic placeholder thumbnail\"></div>";
		newElement += "<p >  Type: " + item.type  + "</p>";
		newElement += "</div>";
		newElement += "</div>";
		
		newElement += "<table class=\"table\" style=\"font-size:10pt;\">";
		newElement += "<tbody>";
		newElement += "<tr>";
		newElement += "<td>Price: $<span>" + item.price + "</span></td>";
		newElement += "<td align=\"right\">Category: <span class=\"badge\">" + item.category + "</span></td>";
		newElement += "</tr>";
		newElement += "</tbody>";
		newElement += "</table>";
		newElement += "</div>";
		newElement += "</div>";
	}

	element.innerHTML = newElement;
}

//add more
function editItem(url,id, itemId){
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			
			var items = JSON.parse(xmlhttp.responseText);
			populateEdit(id, items, itemId);
		}
	}
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
	
}

//need to fix
function postItem(){
	
	var url = 'javascripts/items.json';
	
	var item = {
			"id":"4",
			"user": "lelel",
			"model": "ROG Model 10",
			"category": "Computer",
			"type": "Gaming Laptop",
			"brand": "ASUS",
			"price": 1500,
			"thumb": "http://i1-news.softpedia-static.com/images/news2/ASUS-ROG-G73SW-Is-a-17-3-Inch-Sandy-Bridge-Gaming-Laptop-2.jpg"

		};
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			var items = JSON.parse(xmlhttp.responseText);
			alert (items.length + " items in database");
			items.push (item);
			alert(items.length + " items in database");
		}
	}
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}


function commitUpdateItem(){
	alert("Great you updated the item, but it does want to change!");
	document.getElementById("item-edit").style.display = "none";
	document.getElementById("inventory-view").style.display = "block";
}



//go back button
function goBack(){
	window.history.back();
}

//sample password handle
function val(user, password){
	if(user == "mysite" && password == "123")
		return true;
	else 
		return false;
}

//sample log out
function logout(){
	window.open("login.html",'_self',false);
}

//sample log in
function login(user_id, password_id){
	
	var user = document.getElementById(user_id).value;
	var password = document.getElementById(password_id).value;
	
	if(val(user, password)){
		window.alert ("Successful!");
		window.open("#/user/summary",'_self',false);
	}
	
	else 
		window.alert("Wrong username/password entered.")
}

//sample handle menu
// function handleMenu(){
	// if(loggedIn){
		// document.getElementById("logIn").style.display = "none";
		// document.getElementById("logOut").style.display = "block";
	// }
	// else{
		// document.getElementById("logIn").style.display = "block";
		// document.getElementById("logOut").style.display = "none";
	// }
// }


function iniIndex(){
	retrieveItemsFromServer('javascripts/items.json','allItems',2);
}

//sample init  user page
function initUserAccount(x){
	if(x=='general-info'){
		document.getElementById("general-info").style.display = "block";
		document.getElementById("inventory-view").style.display = "none";
		document.getElementById("list-items").style.display = "none";
		document.getElementById("item-edit").style.display = "none";
		
	}
	else if(x=='list-items'){
		document.getElementById("list-items").style.display = "block";
		document.getElementById("inventory-view").style.display = "none";
		document.getElementById("general-info").style.display = "none";
		document.getElementById("item-edit").style.display = "none";
	}
	else if(x=='inventory-view'){
		document.getElementById("inventory-view").style.display = "block";
		document.getElementById("general-info").style.display = "none";
		document.getElementById("list-items").style.display = "none";
		retrieveItemsFromServer('javascripts/items.json', x,1);
		//populateItemsView(x);
	}
	
	else{
		
		document.getElementById("list-items").style.display = "none";
	}
}







