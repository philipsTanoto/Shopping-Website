var express = require('express');
var url = require('url');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var uriUtil = require("mongodb-uri");
var util = require('util');
var morgan = require('morgan');
var methodOverride = require('method-override');
var session = require('express-session');
var MongoStore = require('connect-mongo')(session);
var crypto = require('crypto');
var http = require("http");
var FacebookStrategy = require('passport-facebook').Strategy;
var passport = require('passport');
// create application/json parser
var jsonParser = bodyParser.json();
// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/', express.static('./public/'));
//app.use('/login',express.static('./public/modules/login/views/login.html'));
var item;
var idGenerator = 100;

var options = { server: { socketOptions: { keepAlive: 1, connectTimeoutMS: 30000 } } }; 


app.use(session({ 
		secret: 'keyboard cat',
		store: new MongoStore({ 
			mongooseConnection: mongoose.connection,
			collection: 'sessions'
		})
}));

console.log('Sending connecting request with Mongo db');
mongoose.connection.on('error', function() {
	console.log("problems connecting to the MongoDB server");
});




//put config url behind file to hide passwords and username
var mongoDBConnection = require('./db.itemsSample.config');
console.log(mongoDBConnection.uri);

mongoose.connect(mongoDBConnection.uri);
mongoose.connection.on('open', function() {
	var Schema = mongoose.Schema;
	var ItemsSchema = new Schema( 
		{
			//_id: {type: String},
			category: {type: String, required: true},
			type: {type: String, required: true},
			brand: {type: String, required: true},
			model: {type: String, required: true},
			os: {type: String},
			price: {type: Number, required: true},
			condition: {type: String, required: true},
			owner: {type: String},
			onsale: {type: Boolean, default : false},
			description: {type: String, default:"good item!"},
			inCartOf: [{type: String}],
			photo: {type: String, default: "http://cdn-master.tangerinedigital.com/blog/wp-content/uploads/2013/12/Consumer-Durables-Non-Durables-slider.jpg"}
			
		},
	   {collection: 'items'}
	);
	ItemModel = mongoose.model('Items', ItemsSchema);	
	ItemModel.remove();
	
	var UsersSchema = new Schema(
		{
			//_id: {type: String},
			username: {type: String, required: true, unique: true},
			email: {type: String, required: true},
			fName: {type: String, required: true},
			lName: {type: String, required: true},
			hashed_pwd: {type: String},	
			cart: [{type: String}],
			address: {type: String, required: true},
			//own: [{type: String}]
		},
	   {collection: 'users'}
	);
	UserModel = mongoose.model('Users', UsersSchema);	
	UserModel.remove({});
	console.log('models have been created');
});




/*ITEM */

//ADD NEW ITEM
app.post('/item', function (req, res) {
	var item;
	console.log("POST: ");
	console.log(req.body);
	var ownerUser;
	var ownedBy = req.session.username;
    var request  = JSON.stringify(req.body);
	item = new ItemModel({
		category: req.body.category,
		type: req.body.type,
		brand: req.body.brand,
		model: req.body.model,
		os: req.body.os,
		price: req.body.price,
		condition: req.body.condition,
		owner: ownedBy,
		inCartOf: [],
		description: req.body.description,
		photo: req.body.photo
	});
    console.log(req.body);
    item.save(function (err) {
		if (!err) {
			UserModel.findById(req.session.user, function(err,user){
				//user.own.push(item._id);
			});
		  return console.log("created item");
		} else {
		  return console.log(err);
		}
	});
});

//VIEW ONE ITEM
app.get('/item/:itemId/', function (req, res) {
	console.log('Query one items');
	var id = req.params.itemId;
	var result;
	ItemModel.findOne({_id: id},function(err, item) {
		
	  if (err) return console.error(err);
	   result = item;
	   console.log(item);
	   res.send(result);
	});
	
});

//EDIT ONE ITEM
app.put('/item/remove/:itemId', function (req, res){
	
	var item;
	var id = req.params.itemId;
	console.log("PUT: "+id);
    console.log(req.body);
    var ownedBy = req.session.user;
    ItemModel.findById(id, function (err, item) {
		item.category= req.body.category;
		item.type= req.body.type;
		item.brand= req.body.brand;
		item.model= req.body.model;
		item.os= req.body.os;
		item.price= req.body.price;
		item.condition= req.body.condition;
		item.owner= ownedBy;
		item.description= req.body.description;
		item.photo= req.body.photo;
		
		item.save (function (err){
			if (!err) {
			  return console.log("updated item");
			} else {
			  return console.log(err);
			}
		});
		
	});
});

//DELETE AN ITEM BASE ON ID
app.delete('/item/:itemId', function (req, res) {
	console.log('Query one items');
	var id = req.params.itemId;
	var result;
	ItemModel.remove({_id: id},function(err, item) {
	  if (err) return console.error(err);
	   console.log("removed");
	    
	});
});

//GET ALL ITEMS
app.get('/items', function (req, res) {
		var allItems;
		ItemModel.find({},function(err, items) {
		  if (err) return console.error(err);
		   allItems = items;
		   res.send(allItems);
		});
});

//VIEW ALL ITEMS BELONGS TO A USER
app.get('/item', function (req, res) {
	if (req.session.user) {
		console.log("user id:" + req.session.user);
		var allItems;
		ItemModel.find({owner: req.session.username},function(err, items) {
		  if (err) return console.error(err);
		   allItems = items;
		   res.send(allItems);
		});
	}else{
		res.send('need to login');
	}
});

//ADD ITEM TO CART
app.put('/cart/:itemId',function (req, res) {
	var id = req.params.itemId;
	
	var user ;
	
	if (req.session.user) {
		UserModel.findById(req.session.user, function(err,user){
			user.cart.push(id);
			var item;
			ItemModel.findById(id, function (err,item){
				item.inCartOf.push(req.session.user);
				item.save(function (err) {
					if (!err) {
					  return console.log("added watching user");
					} else {
					  return console.log(err);
					}	
				});
				console.log(item);
			});
			console.log(user);
			user.save(function (err) {
				if (!err) {
				  return console.log("user added new item to cart");
				} else {
				  return console.log(err);
				}
			});
		});
		
	}else{
		res.send('need to login');
	}
});

//VIEW CART
app.get('/cart', function (req, res) {
	if (req.session.user) {
		console.log("user id:" + req.session.user);
		var allItems;
		ItemModel.find({inCartOf: req.session.user},function(err, items) {
			console.log(items);
		  if (err) return console.error(err);
		   allItems = items;
		   res.send(allItems);
		});
	}else{
		res.send('need to login');
	}
});

//DELETE AN ITEM out of cart
app.put('/cart/remove/:itemId', function (req, res) {
	var id = req.params.itemId;
	
	var user ;
	
	if (req.session.user) {
		UserModel.findById(req.session.user, function(err,user){
			user.cart.pull(id);
			var item;
			ItemModel.findById(id, function (err,item){
				item.inCartOf.pull(req.session.user);
				item.save(function (err) {
					if (!err) {
					  return console.log("removed watching user");
					} else {
					  return console.log(err);
					}	
				});
				console.log(item);
			});
			console.log(user);
			user.save(function (err) {
				if (!err) {
				  return console.log("user removed item to cart");
				} else {
				  return console.log(err);
				}
			});
		});
		
	}else{
		res.send('need to login');
	}
});

/*USER*/
app.get('/users', function (req, res) {
	var query = UserModel.find({username: 'oteee'});
	console.log(query);
});

//CREATE NEW USER
app.post('/user', function (req, res) {
	var user;
	console.log("POST: ");
    var request  = JSON.stringify(req.body);
	var hashedPwd = crypto.createHash('sha256').update(req.body.password).digest('base64').toString();
	user = new UserModel({
		username: req.body.username,
		email: req.body.email,
		fName: req.body.fName,
		lName: req.body.lName,
		hashed_pwd: hashedPwd,	
		//cart: [],
		address: req.body.address,
		//own: []
	});
    console.log(user);
    user.save(function (err) {
		if (!err) {
		  return console.log("created user");
		} else {
		  return console.log(err);
		}
	});
	UserModel.find();
	res.send('#/login');
});


//LOGIN WITH USERNAME PARAM
app.get('/login/:username', function (req, res) {
	console.log("making a login request to server");
	console.log(req);
	var id = req.params.username;
	
	console.log("calling retrieve user Id");
	var query = UserModel.findOne({username:id});
	query.exec(function (err, user) {
		if (!user) {
			res.sendStatus(404);
		}
		else {
				req.session.user = user._id.valueOf();
				req.session.username = user.username;
				req.session.email = user.email;
		}
		if (err) {
			console.log("errors accessing users");
		}
		else {
			console.log("----------->user info:" + user);
			res.sendStatus(200);
		}
	});	
});

//LOGIN
app.post('/login/', function (req, res) {
	console.log("making a login request to server via form");
	console.log(req);
	var id = req.body.username;
	console.log("calling retrieve user Id");

	var query = UserModel.findOne({username:id});
	query.exec(function (err, user) {
		if (!user) {
			req.session.user = undefined;
			res.sendStatus(404);
			return;
		}
		else {
			var pwd = req.body.password;
			var hashedPwd = crypto.createHash('sha256').update(pwd).digest('base64').toString();
			
			if (hashedPwd === user.hashed_pwd) {
				req.session.user = user._id.valueOf();
				req.session.username = user.username;
				req.session.email = user.email;
				console.log('user information is correct');
			}
			else {
				console.log(req.body.password);
				console.log('incorrect password');
			}
		}
		if (err) {
			console.log("errors accessing users");
		}
		else {
			
			console.log("----------->user info:" + user);
			res.sendStatus(200);
		}
	});	
});


module.exports = app;
