console.log('starting test');
var chai = require('chai');
var chaiHttp = require('chai-http');
var async = require('async');

var assert = chai.assert;
var expect = chai.expect;
var should = chai.should();

var http = require('http');
chai.use(chaiHttp);

if (!global.Promise) {
  var q = require('q');
  chai.request.addPromises(q.Promise);
}

describe('Test app.get routes', function () {
	this.timeout(15000);
	
	var requestResult;
	var response;
		 
	before(function(done) {
		chai.request('http://groupsupercool.azurewebsites.net/')
			.get('/item')
			.end(function (err, res) {
				requestResult = res.body;
				response = res;
				done();
			});
	});

	it('Should return an object', function(done){
		expect(response).to.have.status(200);
		expect(requestResult).to.be.an.object;
		expect(requestResult).to.have.length.above(0);
		expect(response).to.have.headers;
		done();
	});
	it('The first entry in the array has known properties', function(done){
		expect(requestResult[0]).to.include.keys('__v');
		expect(requestResult[0]).to.include.keys('_id');
		expect(requestResult[0]).to.include.keys('brand');
		expect(requestResult[0]).to.include.keys('category');
		expect(requestResult[0]).to.include.keys('condition');
		expect(requestResult[0]).to.include.keys('description');
		expect(requestResult[0]).to.include.keys('inCartOf');
		expect(requestResult[0]).to.include.keys('model');
		expect(requestResult[0]).to.include.keys('onsale');
		expect(requestResult[0]).to.include.keys('os');
		expect(requestResult[0]).to.include.keys('owner');
		expect(requestResult[0]).to.include.keys('photo');
		expect(requestResult[0]).to.include.keys('price');
		expect(requestResult[0]).to.include.keys('type');	
		expect(response.body).to.not.be.a.string;
		done();
	});
	
	
	it('/item', function(done){
		chai.request('http://groupsupercool.azurewebsites.net/')
		 .get('/item')
		 .end(function (err, res) {
			expect(err).to.be.null;
			expect(res).to.have.status(200);
			expect(res.body).to.be.an.object;
			expect(res.body).to.have.length.above(0);
			expect(res.body[0]).to.include.keys('__v');
			expect(res.body[0]).to.include.keys('_id');
			expect(res.body[0]).to.include.keys('brand');
			expect(res.body[0]).to.include.keys('category');
			expect(res.body[0]).to.include.keys('condition');
			expect(res.body[0]).to.include.keys('description');
			expect(res.body[0]).to.include.keys('inCartOf');
			expect(res.body[0]).to.include.keys('model');
			expect(res.body[0]).to.include.keys('onsale');
			expect(res.body[0]).to.include.keys('os');
			expect(res.body[0]).to.include.keys('owner');
			expect(res.body[0]).to.include.keys('photo');
			expect(res.body[0]).to.include.keys('price');
			expect(res.body[0]).to.include.keys('type');
			done();
		 });
	});

	it('/items', function(done){
		chai.request('http://localhost:3000')
		 .get('/items')
		 .end(function (err, res) {
			expect(err).to.be.null;
			expect(res).to.have.status(200);
			expect(res.body).to.be.an.object;
			expect(res.body).to.have.length.above(0);
			expect(res.body[0]).to.include.keys('__v');
			expect(res.body[0]).to.include.keys('_id');
			expect(res.body[0]).to.include.keys('brand');
			expect(res.body[0]).to.include.keys('category');
			expect(res.body[0]).to.include.keys('condition');
			expect(res.body[0]).to.include.keys('description');
			expect(res.body[0]).to.include.keys('inCartOf');
			expect(res.body[0]).to.include.keys('model');
			expect(res.body[0]).to.include.keys('onsale');
			expect(res.body[0]).to.include.keys('os');
			expect(res.body[0]).to.include.keys('owner');
			expect(res.body[0]).to.include.keys('photo');
			expect(res.body[0]).to.include.keys('price');
			expect(res.body[0]).to.include.keys('type');
			done();
		 });
	});
	
	it('/item/:itemId', function(done){
		chai.request('http://localhost:3000')
		 .get('/item/55677ca8dda20d7c2250a5ee')
		 //.query({_id:})
		 .end(function (err, res) {
			expect(err).to.be.null;
			expect(res).to.have.status(200);
			expect(res.body).to.be.an.object;
			//expect(res.body).to.have.length.above(0);
			expect(res.body).to.include.keys('__v');
			expect(res.body).to.include.keys('_id');
			expect(res.body).to.include.keys('brand');
			expect(res.body).to.include.keys('category');
			expect(res.body).to.include.keys('condition');
			expect(res.body).to.include.keys('description');
			expect(res.body).to.include.keys('inCartOf');
			//expect(res.body).to.have.deep.property('inCartOf').that.is.an('array');
			expect(res.body).to.include.keys('model');
			expect(res.body).to.include.keys('onsale');
			expect(res.body).to.include.keys('os');
			expect(res.body).to.include.keys('owner');
			expect(res.body).to.include.keys('photo');
			expect(res.body).to.include.keys('price');
			expect(res.body).to.include.keys('type');
			done();
		 });
	});	
	
	it('/login/:username', function(done){
		chai.request('http://localhost:3000')
		 .get('/login/philip')
		 //.query({_id:})
		 .send({ username: 'aaa', password: '1' })
		 .end(function (err, res) {
			expect(err).to.be.null;
			expect(res).to.be.an.object;
			// expect(res.body).to.be.an.object;
			//expect(res.body).to.have.length.above(0);
			// expect(res.body).to.be("[]");
			// expect(res.body).to.include.keys('username');
			// expect(res.body).to.include.keys('__v');
			// expect(res.body).to.include.keys('_id');
			// expect(res.body).to.include.keys('fName');
			// expect(res.body).to.include.keys('lName');
			// expect(res.body).to.include.keys('hashed_pwd');
			// expect(res.body).to.include.keys('address');
			// expect(res.body).to.include.keys('cart');
			done();
		 });
	});
	
	
	
  });